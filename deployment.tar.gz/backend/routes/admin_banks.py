from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from database import get_db
from models.banks import Banks
from models.bank_analytics import BankAnalytics
from models.bank_case_statistics import BankCaseStatistics
from schemas.admin import BankCreateRequest, BankUpdateRequest
from typing import List, Optional
import math
import json

router = APIRouter()

@router.get("/stats")
async def get_banks_stats(db: Session = Depends(get_db)):
    """Get comprehensive bank statistics for admin dashboard"""
    try:
        # Basic counts
        total_banks = db.query(Banks).count()
        
        # Financial analysis
        total_assets = db.query(Banks.total_assets).filter(Banks.total_assets.isnot(None)).all()
        total_assets = sum([assets[0] for assets in total_assets]) if total_assets else 0
        
        total_branches = db.query(Banks.branches_count).filter(Banks.branches_count.isnot(None)).all()
        total_branches = sum([branches[0] for branches in total_branches]) if total_branches else 0
        
        # Average rating
        avg_rating = db.query(Banks.rating).filter(Banks.rating.isnot(None)).all()
        avg_rating = sum([rating[0] for rating in avg_rating]) / len(avg_rating) if avg_rating else 0
        
        # Active banks
        active_banks = db.query(Banks).filter(Banks.is_active == True).count()
        
        return {
            "total_banks": total_banks,
            "total_assets": total_assets,
            "total_branches": total_branches,
            "avg_rating": avg_rating,
            "active_banks": active_banks,
            "last_updated": db.query(Banks.updated_at).order_by(Banks.updated_at.desc()).first()[0].isoformat() if db.query(Banks.updated_at).first() else None
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching banks stats: {str(e)}")

@router.get("/")
async def get_banks(
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    search: Optional[str] = Query(None),
    bank_type: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Get paginated list of banks with optional filtering"""
    try:
        query = db.query(Banks)
        
        # Apply search filter
        if search:
            query = query.filter(
                Banks.name.ilike(f"%{search}%") |
                Banks.short_name.ilike(f"%{search}%") |
                Banks.email.ilike(f"%{search}%")
            )
        
        # Apply bank type filter
        if bank_type:
            query = query.filter(Banks.bank_type == bank_type)
        
        # Get total count
        total = query.count()
        
        # Apply pagination
        offset = (page - 1) * limit
        banks = query.offset(offset).limit(limit).all()
        
        # Convert JSON arrays to strings for API response
        formatted_banks = []
        for bank in banks:
            bank_dict = bank.__dict__.copy()
            
            # Convert JSON arrays to comma-separated strings
            if bank_dict.get('previous_names') and isinstance(bank_dict['previous_names'], list):
                bank_dict['previous_names'] = ', '.join(bank_dict['previous_names']) if bank_dict['previous_names'] else ''
            elif bank_dict.get('previous_names') is None or bank_dict.get('previous_names') == []:
                bank_dict['previous_names'] = ''
                
            if bank_dict.get('services'):
                if isinstance(bank_dict['services'], list):
                    bank_dict['services'] = ', '.join(bank_dict['services']) if bank_dict['services'] else ''
                elif isinstance(bank_dict['services'], str) and bank_dict['services'].startswith('['):
                    # Handle JSON string format
                    import json
                    try:
                        services_list = json.loads(bank_dict['services'])
                        bank_dict['services'] = ', '.join(services_list) if services_list else ''
                    except:
                        bank_dict['services'] = bank_dict['services']  # Keep as is if parsing fails
            elif bank_dict.get('services') is None or bank_dict.get('services') == []:
                bank_dict['services'] = ''
            
            # Remove SQLAlchemy internal attributes
            bank_dict.pop('_sa_instance_state', None)
            formatted_banks.append(bank_dict)
        
        # Calculate total pages
        total_pages = math.ceil(total / limit)
        
        return {
            "banks": formatted_banks,
            "total": total,
            "page": page,
            "limit": limit,
            "total_pages": total_pages
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching banks: {str(e)}")

@router.get("/{bank_id}")
async def get_bank(bank_id: int, db: Session = Depends(get_db)):
    """Get detailed information about a specific bank"""
    try:
        bank = db.query(Banks).filter(Banks.id == bank_id).first()
        if not bank:
            raise HTTPException(status_code=404, detail="Bank not found")
        
        # Get analytics if available
        analytics = db.query(BankAnalytics).filter(BankAnalytics.bank_id == bank_id).first()
        case_stats = db.query(BankCaseStatistics).filter(BankCaseStatistics.bank_id == bank_id).first()
        
        # Convert bank data for API response
        bank_dict = bank.__dict__.copy()
        
        # Convert JSON arrays to comma-separated strings
        if bank_dict.get('previous_names') and isinstance(bank_dict['previous_names'], list):
            bank_dict['previous_names'] = ', '.join(bank_dict['previous_names']) if bank_dict['previous_names'] else ''
        elif bank_dict.get('previous_names') is None or bank_dict.get('previous_names') == []:
            bank_dict['previous_names'] = ''
            
        if bank_dict.get('services'):
            if isinstance(bank_dict['services'], list):
                bank_dict['services'] = ', '.join(bank_dict['services']) if bank_dict['services'] else ''
            elif isinstance(bank_dict['services'], str) and bank_dict['services'].startswith('['):
                # Handle JSON string format
                import json
                try:
                    services_list = json.loads(bank_dict['services'])
                    bank_dict['services'] = ', '.join(services_list) if services_list else ''
                except:
                    bank_dict['services'] = bank_dict['services']  # Keep as is if parsing fails
        elif bank_dict.get('services') is None or bank_dict.get('services') == []:
            bank_dict['services'] = ''
        
        # Remove SQLAlchemy internal attributes
        bank_dict.pop('_sa_instance_state', None)
        
        return {
            "bank": bank_dict,
            "analytics": analytics,
            "case_statistics": case_stats
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching bank: {str(e)}")

@router.post("/")
async def create_bank(bank_data: BankCreateRequest, db: Session = Depends(get_db)):
    """Create a new bank"""
    try:
        # Convert comma-separated strings to JSON arrays for storage
        bank_dict = bank_data.dict()
        
        # Convert string fields to JSON arrays
        if bank_dict.get('previous_names'):
            bank_dict['previous_names'] = [name.strip() for name in bank_dict['previous_names'].split(',') if name.strip()]
        else:
            bank_dict['previous_names'] = []
            
        if bank_dict.get('services'):
            bank_dict['services'] = [service.strip() for service in bank_dict['services'].split(',') if service.strip()]
        else:
            bank_dict['services'] = []
        
        # Create the bank
        bank = Banks(**bank_dict)
        db.add(bank)
        db.commit()
        db.refresh(bank)
        
        return {"message": "Bank created successfully", "bank_id": bank.id}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error creating bank: {str(e)}")

@router.put("/{bank_id}")
async def update_bank(bank_id: int, bank_data: BankUpdateRequest, db: Session = Depends(get_db)):
    """Update an existing bank"""
    try:
        bank = db.query(Banks).filter(Banks.id == bank_id).first()
        if not bank:
            raise HTTPException(status_code=404, detail="Bank not found")
        
        # Convert comma-separated strings to JSON arrays for storage
        update_data = bank_data.dict(exclude_unset=True)
        
        # Convert string fields to JSON arrays
        if 'previous_names' in update_data and update_data['previous_names']:
            update_data['previous_names'] = [name.strip() for name in update_data['previous_names'].split(',') if name.strip()]
        elif 'previous_names' in update_data and not update_data['previous_names']:
            update_data['previous_names'] = []
            
        if 'services' in update_data and update_data['services']:
            update_data['services'] = [service.strip() for service in update_data['services'].split(',') if service.strip()]
        elif 'services' in update_data and not update_data['services']:
            update_data['services'] = []
        
        # Update the bank
        for field, value in update_data.items():
            setattr(bank, field, value)
        
        db.commit()
        db.refresh(bank)
        
        return {"message": "Bank updated successfully"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating bank: {str(e)}")

@router.delete("/{bank_id}")
async def delete_bank(bank_id: int, db: Session = Depends(get_db)):
    """Delete a bank and all associated data"""
    try:
        bank = db.query(Banks).filter(Banks.id == bank_id).first()
        if not bank:
            raise HTTPException(status_code=404, detail="Bank not found")
        
        # Delete associated analytics and statistics
        db.query(BankAnalytics).filter(BankAnalytics.bank_id == bank_id).delete()
        db.query(BankCaseStatistics).filter(BankCaseStatistics.bank_id == bank_id).delete()
        
        # Delete the bank
        db.delete(bank)
        db.commit()
        
        return {"message": "Bank deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting bank: {str(e)}")
